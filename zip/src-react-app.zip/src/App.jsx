import React from "react";
import HelloFromReact from "./HelloFromReact";

function App() {
  return <HelloFromReact />;
}

export default App;
