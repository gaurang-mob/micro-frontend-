import React from "react";

function HelloFromReact() {
  return <h1> Hello From React</h1>;
}

export default HelloFromReact;